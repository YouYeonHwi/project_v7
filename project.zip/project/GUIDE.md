# 가전 CS 진단 에이전트 — 프로젝트 가이드

## 무엇을 만드나
가전제품 에러 디스플레이 **이미지 한 장**을 넣으면, 시스템이 알아서:
- 매뉴얼에 있는 에러 → **안내 메시지** 생성
- 매뉴얼에 없는 에러 → **CS 티켓 JSON** 생성

라우팅은 고정 파이프라인이 아니라 **supervisor 가 동적으로 결정**한다.

## 구조 (LangGraph supervisor pattern)
```
START → supervisor ─(조건부)─► inspector / researcher / resolver / END
        inspector  → supervisor
        researcher → supervisor
        resolver   → END
```
- **inspector** — 이미지 → 증상 텍스트 (VLM)
- **researcher** — 매뉴얼 조회(`lookup_manual` tool) + 확신도 판단
- **resolver** — 안내 메시지 또는 티켓 작성
- **supervisor** — 다음 노드 결정 (라우터)

## 6개 TODO
| TODO | 내용 |
|------|------|
| T1 | Chunking + Chroma 벡터스토어 구축 |
| T2 | Hybrid retriever (BM25 + dense) |
| T3 | Cross-encoder rerank |
| T4 | `lookup_manual` 을 `@tool` 로 노출 |
| T5 | researcher 노드 — tool 호출 + threshold 판단 |
| T6 | supervisor 라우터 + 그래프 구축 |

## 데이터 (노트북 내 인라인으로 제공)
- 매뉴얼 17항목 / 8기종 (세탁기·건조기·냉장고·에어컨·전자레인지·식기세척기·TV·청소기)
- 평가셋 12쌍, 테스트 이미지 4종

## 실행 준비
1. 터미널에서 `bash start_llama_server.sh` (llama-server 기동, 포트 8080)
2. 환경변수 `OPENAI_BASE_URL` / `OPENAI_API_KEY` (임베딩 프록시)
3. 노트북을 위에서부터 순서대로 실행

## 모델
- LLM/VLM: Qwen3.5-4B Q8_0 (on-device llama-server)
- 임베딩: text-embedding-3-small (프록시)
- 리랭커: bge-reranker-v2-m3 (multilingual)

## 채점 기준
`Recall@3 ≥ 0.83`, `MRR@3 ≥ 0.80`
