#!/usr/bin/env bash
# =============================================================================
# 심화반 프로젝트용 llama-server 기동 스크립트
#
# 사용법:
#   터미널을 새로 열고 다음을 실행:
#     bash start_llama_server.sh
#   서버가 백그라운드 컨테이너로 기동됨. 완료 후 노트북으로 돌아가서
#   Section 0 의 health-poll 셀을 실행.
#
# 모델: Qwen3.5-4B Q8_0 + mmproj-F16 (DAY3_01 스모크 테스트와 동일)
# 포트: 8080 (project notebook 도 동일하게 가정)
# =============================================================================

set -euo pipefail

CONTAINER_NAME="llama-server-project"
HOST_PORT=8080
MODEL_DIR="${HOME}/models"
IMAGE="ghcr.io/ggml-org/llama.cpp:server-cuda"

# -----------------------------------------------------------------------------
# 1. 사전 점검: docker 실행 가능 여부 + GPU 인식
# -----------------------------------------------------------------------------
echo "==> Docker 및 GPU 점검"
if ! command -v docker &>/dev/null; then
    echo "  ✗ docker 명령을 찾을 수 없습니다. 설치 상태 확인 필요." >&2
    exit 1
fi
docker info &>/dev/null || { echo "  ✗ docker 데몬이 실행 중이 아닙니다." >&2; exit 1; }
echo "  ✓ docker OK"

# -----------------------------------------------------------------------------
# 2. 모델 파일 위치 확인 (스모크 테스트에서 이미 다운로드됨)
# -----------------------------------------------------------------------------
echo "==> 모델 파일 탐색 (${MODEL_DIR})"
MODEL_PATH=$(find "${MODEL_DIR}" -type f -name '*Q8_0*.gguf' ! -iname '*mmproj*' 2>/dev/null | sort | head -1 || true)
MMPROJ_PATH=$(find "${MODEL_DIR}" -type f -iname '*mmproj*.gguf' 2>/dev/null | sort | head -1 || true)

if [[ -z "${MODEL_PATH}" || -z "${MMPROJ_PATH}" ]]; then
    echo "  ✗ 모델 파일을 찾을 수 없습니다." >&2
    echo "    DAY3_01 스모크 테스트 노트북을 먼저 실행해서 다음 파일을 받아두세요:" >&2
    echo "      - Qwen3.5-4B-Q8_0.gguf" >&2
    echo "      - mmproj-F16.gguf" >&2
    echo "    위 두 파일이 ${MODEL_DIR} 하위에 있어야 합니다." >&2
    exit 1
fi

# 컨테이너 내부 경로로 변환 (MODEL_DIR 전체를 /models 로 마운트)
MODEL_CONT="/models/$(realpath --relative-to="${MODEL_DIR}" "${MODEL_PATH}")"
MMPROJ_CONT="/models/$(realpath --relative-to="${MODEL_DIR}" "${MMPROJ_PATH}")"

echo "  ✓ 모델:   ${MODEL_PATH}"
echo "  ✓ mmproj: ${MMPROJ_PATH}"

# -----------------------------------------------------------------------------
# 3. 기존 컨테이너 정리 (재실행 시를 대비)
# -----------------------------------------------------------------------------
echo "==> 기존 ${CONTAINER_NAME} 컨테이너 정리"
docker rm -f "${CONTAINER_NAME}" &>/dev/null || true
echo "  ✓ 정리 완료"

# -----------------------------------------------------------------------------
# 4. 포트 충돌 확인
# -----------------------------------------------------------------------------
if ss -tln 2>/dev/null | grep -q ":${HOST_PORT} "; then
    echo "  ⚠ 포트 ${HOST_PORT} 이 이미 사용 중입니다." >&2
    echo "    다른 llama-server 인스턴스가 떠 있는지 확인하세요:" >&2
    echo "      docker ps" >&2
    exit 1
fi

# -----------------------------------------------------------------------------
# 5. 서버 기동 (detached)
# -----------------------------------------------------------------------------
echo "==> llama-server 기동"
docker run -d --rm --name "${CONTAINER_NAME}" \
    --gpus all \
    -p "${HOST_PORT}:8080" \
    -v "${MODEL_DIR}:/models" \
    "${IMAGE}" \
    -m "${MODEL_CONT}" \
    --mmproj "${MMPROJ_CONT}" \
    --host 0.0.0.0 --port 8080 \
    --n-gpu-layers 99 \
    --ctx-size 4096 \
    --jinja \
    --reasoning-budget 0 \
    > /dev/null

echo "  ✓ 컨테이너 시작됨"
echo

# -----------------------------------------------------------------------------
# 6. 상태 표시
# -----------------------------------------------------------------------------
sleep 2
docker ps --filter "name=${CONTAINER_NAME}" \
    --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'

echo
echo "==> 다음 단계"
echo "  - 모델 가중치 로딩에 약 10~30 초 소요됩니다."
echo "  - 프로젝트 노트북의 Section 0 health-poll 셀을 실행하세요."
echo "  - 서버 로그 확인:    docker logs -f ${CONTAINER_NAME}"
echo "  - 서버 종료:         docker stop ${CONTAINER_NAME}"
